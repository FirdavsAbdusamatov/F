
<?php 
  echo'<b>';
  echo"hloo";
  echo '9';
 ?>